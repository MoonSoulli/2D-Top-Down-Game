extends CanvasLayer

@onready var score_label: Label = $ScoreLabel
@onready var highscore_label: Label = $HighscoreLabel

func _process(_delta: float) -> void:
	# Continuously pull data from the global ScoreManager
	score_label.text = "SCORE: " + str(ScoreManager.current_score)
	highscore_label.text = "HIGHSCORE: " + str(ScoreManager.highscore)
