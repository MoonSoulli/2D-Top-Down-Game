extends CharacterBody2D

const SPEED = 500.0
const KNOCKBACK_FORCE = 150.0 

var health: int = 500

var is_alive: bool = true
var is_attacking: bool = false
var enemies_already_hit: Array = []

@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
@onready var attack_area: Area2D = $AttackArea
@onready var attack_shape: CollisionShape2D = $AttackArea/CollisionShape2D


var last_direction: Vector2 = Vector2.RIGHT


func _ready() -> void:
	add_to_group("player")
	attack_shape.disabled = true


func _physics_process(_delta: float) -> void:
	if not is_alive: return

	process_movement()
	
	if Input.is_action_just_pressed("attack"):
		attack()
		
	process_animation()
	move_and_slide()


func process_movement() -> void:
	var direction := Input.get_vector("left", "right", "up", "down")
	
	if direction != Vector2.ZERO:
		velocity = direction * SPEED
		last_direction = direction
	else:
		velocity = Vector2.ZERO
	
	update_hitbox_direction()


func update_hitbox_direction() -> void:
	if last_direction.x < 0:
		attack_area.scale.x = -1
	elif last_direction.x > 0:
		attack_area.scale.x = 1

func attack() -> void:
	is_attacking = true
	attack_shape.disabled = false
	
	# SỬA LỖI 2: Mỗi khi click chém, làm trống danh sách đã trúng đòn
	enemies_already_hit.clear()
	
	animated_sprite_2d.play("attack_right")
	animated_sprite_2d.frame = 0 


func take_damage(damage: int, attacker_position: Vector2) -> void:
	if not is_alive: return
	health -= damage
	if health <= 0:
		_die()
	else:
		var knockback_direction = (position - attacker_position).normalized()
		var target_knockback_position = position + (knockback_direction * KNOCKBACK_FORCE)
		var tween = create_tween()
		tween.set_ease(Tween.EASE_OUT)
		tween.set_trans(Tween.TRANS_CUBIC)
		tween.tween_property(self, "position", target_knockback_position, 0.3)


func _die() -> void:
	is_alive = false
	velocity = Vector2.ZERO
	animated_sprite_2d.play("death_right")
	

func process_animation() -> void:
	if not is_alive: return
	if is_attacking: return 
	if velocity != Vector2.ZERO:
		play_animation("run", last_direction)
	else:
		play_animation("idle", last_direction)

func play_animation(prefix: String, dir: Vector2) -> void:
	if dir.x != 0:
		animated_sprite_2d.flip_h = dir.x < 0
	animated_sprite_2d.play(prefix + "_right")

# --- SIGNALS ---

func _on_animated_sprite_2d_animation_finished() -> void:
	if animated_sprite_2d.animation == "attack_right":
		is_attacking = false
		attack_shape.disabled = true

		enemies_already_hit.clear()

func _on_attack_area_body_entered(body: Node2D) -> void:
	if body.has_method("take_damage") and body != self:
		if not enemies_already_hit.has(body):
			enemies_already_hit.append(body) 
			var current_damage = 50
			print("Hero hit monster: ", body.name, " (", current_damage, " Damage)")
			body.take_damage(current_damage, global_position)
